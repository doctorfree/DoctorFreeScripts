#!/bin/bash

ifttt off
