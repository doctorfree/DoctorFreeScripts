#!/bin/bash

ifttt appletv $*
