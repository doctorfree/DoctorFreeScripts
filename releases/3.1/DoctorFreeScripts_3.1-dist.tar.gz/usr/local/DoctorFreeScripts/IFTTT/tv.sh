#!/bin/bash

ifttt tv $*
