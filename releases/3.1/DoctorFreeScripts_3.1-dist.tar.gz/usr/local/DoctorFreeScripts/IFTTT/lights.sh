#!/bin/bash

ifttt lights $*
