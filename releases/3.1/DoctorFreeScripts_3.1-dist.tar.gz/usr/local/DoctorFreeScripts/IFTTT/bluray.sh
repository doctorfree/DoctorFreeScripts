#!/bin/bash

ifttt bluray $*
